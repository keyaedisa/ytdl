from setuptools import setup

setup(
    name='tubie',
    version='0.1',
    description='A simple youtube video downloader',
    author='keyaedisa',
    packages=['tubie'],
)

