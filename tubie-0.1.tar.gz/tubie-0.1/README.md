# ytdl
Basic youtube video downloader. Don't use it in anyway that could get me in trouble. Please feel free to contribute and improve.
